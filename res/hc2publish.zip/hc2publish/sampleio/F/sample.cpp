#include "boomerang.h"
#include "math.h"

int main(int argc, char** argv)
{
	const double totaltime = 1;
	while(1)
	{
		int maxqueries = queries_left();
		double distance=0;
		int i;
		for(i=0;i<maxqueries-1;++i)
		{
			double x1 = positionx(i/(maxqueries-1.));
			double y1 = positiony(i/(maxqueries-1.));
			double x2 = positionx((i+1)/(maxqueries-1.));
			double y2 = positiony((i+1)/(maxqueries-1.));
			
			distance += sqrt( (x2-x1)*(x2-x1) + (y2-y1)*(y2-y1));
		}

		answer(distance/totaltime);
	}

	return 0; /*We will never get here*/
}
