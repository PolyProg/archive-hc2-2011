/* Sample library*/
/* Note that the real library is different than this!*/
/*
   In this sample library, we use the following functions:
   First testcase (straight line from (1, 0) to (-2, 0) ):
   x(t) = 2*t^2 - 5*t + 1
   y(t) = 0

   Second testcase (circle of radius 1 around the origin):
   x(t) = cos(2*pi*t)
   y(t) = sin(2*pi*t)
*/

#include "boomerang.h"
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

static const int max_queries=33;
static int testcase = 0;
static double queried[35];
static int nqueried=0;

static void add(double t)
{
	if(t<-1e-8 || t > 1+1e-8)
	{
		printf("t must be in range 0-1. (%.20f)\n", t);
		exit(3);
	}
	if(already_queried(t))
		return;
	queried[nqueried]=t;
	nqueried++;
	if(queries_left() < 0)
	{
		printf("Too many queries. Terminating program.\n");
		exit(1);
	}
}
/*You may call the following 6 functions with at most 33 different*/
/*values of t:*/

/* Returns the X coordinate of the position of the boomerang*/
/*    at time t (0<=t<=1)*/
double positionx(double t){
	add(t);
	if(queries_left() < 0)
	{
		printf("Too many queries. Terminating program.\n");
		exit(1);
	}
	if(testcase==0)
		return 2*t*t-5*t+1;
	else
		return cos(2*M_PI*t);
}
/* Returns the Y coordinate of the position of the boomerang*/
/*    at time t (0<=t<=1)*/
double positiony(double t){
	add(t);
	if(queries_left() < 0)
	{
		printf("Too many queries. Terminating program.\n");
		exit(1);
	}
	if(testcase==0)
		return 0.0;
	else
		return sin(2*M_PI*t);
}
/* Returns the X coordinate of the speed vector of the boomerang*/
/*    at time t (0<=t<=1)*/
double speedx(double t){
	add(t);
	if(queries_left() < 0)
	{
		printf("Too many queries. Terminating program.\n");
		exit(1);
	}
	if(testcase==0)
		return 4*t-5;
	else
		return -2*M_PI*sin(2*M_PI*t);
}
/* Returns the Y coordinate of the speed vector of the boomerang*/
/*    at time t (0<=t<=1)*/
double speedy(double t){
	add(t);
	if(queries_left() < 0)
	{
		printf("Too many queries. Terminating program.\n");
		exit(1);
	}
	if(testcase==0)
		return 0.0;
	else
		return 2*M_PI*cos(2*M_PI*t);
}
/* Returns the X coordinate of the acceleration vector of the boomerang*/
/*    at time t (0<=t<=1)*/
double accelerationx(double t){
	add(t);
	if(queries_left() < 0)
	{
		printf("Too many queries. Terminating program.\n");
		exit(1);
	}
	if(testcase==0)
		return 4.0;
	else
		return -4*M_PI*M_PI*cos(2*M_PI*t);
}
/* Returns the Y coordinate of the acceleration vector of the boomerang*/
/*    at time t (0<=t<=1)*/
double accelerationy(double t){
	add(t);
	if(queries_left() < 0)
	{
		printf("Too many queries. Terminating program.\n");
		exit(1);
	}
	if(testcase==0)
		return 0.0;
	else
		return -4*M_PI*M_PI*sin(2*M_PI*t);
}


/* Has the state at time t (0<=t<=1) already been queried in this*/
/*    testcase?*/
int already_queried(double t){
	int i;
	for(i=0;i<nqueried;++i)
		if(queried[i]==t)
			return 1;
	return 0;
}
/* Returns the number of new queries you are allowed to make in this*/
/*    testcase*/
int queries_left(){
	return max_queries - nqueried;
}


/* Provide your answer (average length of the norm of the speed vector of the boomerang)*/
/*    to this testcase, and go to the next testcase.*/
/*    This function will terminate the program after the last testcase.*/
void answer(double s)
{
	double correct=0;
	if(s<0)
	{
		printf("Speed cannot be negative. Terminating.\n");
		exit(-1);
	}
	switch(testcase)
	{
		case 0: correct=3.0; break;
		case 1: correct=2*M_PI; break;
	}
	printf("Your answer: %f\n", s);
	printf("Correct answer: %f\n", correct);
	printf("Relative error: %f\n", fabs(s-correct)/correct);
	printf("\n");

	testcase++;
	nqueried=0;
	if(testcase==2)
	{
		printf("Program exited normally\n");
		exit(0);
	}
}


