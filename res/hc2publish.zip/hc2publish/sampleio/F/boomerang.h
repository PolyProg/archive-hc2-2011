#ifndef HC2_BOOMERANG_H_
#define HC2_BOOMERANG_H_

/*You may call the following 6 functions with at most 33 different*/
/*values of t:*/

/* Returns the X coordinate of the position of the boomerang*/
/*    at time t (0<=t<=1)*/
double positionx(double t);
/* Returns the Y coordinate of the position of the boomerang*/
/*    at time t (0<=t<=1)*/
double positiony(double t);
/* Returns the X coordinate of the speed vector of the boomerang*/
/*    at time t (0<=t<=1)*/
double speedx(double t);
/* Returns the Y coordinate of the speed vector of the boomerang*/
/*    at time t (0<=t<=1)*/
double speedy(double t);
/* Returns the X coordinate of the acceleration vector of the boomerang*/
/*    at time t (0<=t<=1)*/
double accelerationx(double t);
/* Returns the Y coordinate of the acceleration vector of the boomerang*/
/*    at time t (0<=t<=1)*/
double accelerationy(double t);


/* Has the state at time t (0<=t<=1) already been queried in this*/
/*    testcase? (Returns 1 for true and 0 for false)*/
int already_queried(double t);
/* Returns the number of new queries you are allowed to make in this*/
/*    testcase*/
int queries_left(void);


/* Provide your answer to this testcase, and go to the next testcase.*/
/*    This function will terminate the program after the last testcase.*/
void answer(double t);


#endif /*HC2_BOOMERANG_H_*/
