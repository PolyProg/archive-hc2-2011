class Sample
{
	public static void main(String args[])
	{
		final double totaltime = 1;
		while(true)
		{
			int maxqueries = Boomerang.queries_left();
			double distance=0;
			for(int i=0;i<maxqueries-1;++i)
			{
				double x1 = Boomerang.positionx(i/(maxqueries-1.));
				double y1 = Boomerang.positiony(i/(maxqueries-1.));
				double x2 = Boomerang.positionx((i+1)/(maxqueries-1.));
				double y2 = Boomerang.positiony((i+1)/(maxqueries-1.));
				
				distance += Math.sqrt( (x2-x1)*(x2-x1) + (y2-y1)*(y2-y1));
			}

			Boomerang.answer(distance/totaltime);
		}
	}
}
