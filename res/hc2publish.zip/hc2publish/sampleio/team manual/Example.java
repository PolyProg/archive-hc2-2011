//File name: Example.java 
import java.io.*; 
import java.util.*; 

class Example 
{ 
    static BufferedReader stdin = 
            new BufferedReader( 
            new InputStreamReader(System.in)); 

    public static void main(String args[]) throws Exception 
    {
        String line = stdin.readLine(); 
        StringTokenizer st = new StringTokenizer(line); 

        int ntests = Integer.parseInt(st.nextToken()); 
        for(int i=0;i<ntests;i++) { 
            if(i!=0) 
                System.out.println(); 
            String name = stdin.readLine(); 
            System.out.println("Hello "+name+"!"); 
        } 
    } 
} 
