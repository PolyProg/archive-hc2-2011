#include "terra.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <time.h>

static int C, P;						/* C is the number of cities, P the number of properties*/
static int cityIndex;					/* index of the city Heidi is in*/
static int cityDesc[MAXC][MAXP];		/* description of the cities*/
static int questionCnt;					/* counts the number of questions you asked*/
static int seed;

static int myrand()
{
	int a = 1103515245;
	int c = 12345;

	seed = a*seed + c;

	return seed&0x3FFFFFFF;
}
static void read_input()
{
	static int done=0;
	int ci, p, cc;
	if(done)
		return;
	done=1;

	seed=1;

	cc = myrand()%MAXC + 1;
	P = myrand()%MAXP + 1;

	/*Generate the properties of each city*/
	for(ci=0;ci<cc;++ci)
	{
		int d, ok=1;

		/*Random properties*/
		for(p=0;p<P;++p)
		{
			cityDesc[C][p] = myrand()%MAXV + 1;
		}

		/*Make sure the properties are unique*/
		for(d=0;d<C;++d)
		{
			int same=1;
			for(p=0;p<P;++p)
			{
				if(cityDesc[C][p]!=cityDesc[d][p])
				{
					same=0;
					break;
				}
			}

			if(same)
			{
				ok=0;
				break;
			}
		}

		if(ok)
		{
			C++;
			printf("City %2d has property values: ", C);
			for (p=0; p<P; p++)
				printf("%d ",cityDesc[C-1][p]);
			printf("\n");
		}
	}



	/*Determine starting city*/
	cityIndex = (myrand()%C);

	printf("Heidi will be in city %2d with property values \n",cityIndex+1);
	for (p=0; p<P; p++)
		printf("%d ",cityDesc[cityIndex][p]);
	printf("\n");
	questionCnt = 0;
}

int number_cities()
{
	read_input();
	return C;
}

int number_properties()
{
	read_input();
	return P;
}

void read_catalog(int desc[MAXC][MAXP])
{
	int c, p;
	read_input();
	for (c=0; c<C; c++)
	{
		for (p=0; p<P; p++)
			desc[c][p] = cityDesc[c][p];
	}
}

int heidi_askQuestion(int yourP, int yourV)
{
	read_input();
	assert(yourP>0 && yourP<=P && yourV>0 && yourV<=3);
	questionCnt++;
	
	/* debug information for user*/
	printf("You ask p[%2d] ?= %d  -  Heidi says %d\n",yourP,yourV,cityDesc[cityIndex][yourP-1]==yourV);

	return cityDesc[cityIndex][yourP-1]==yourV;
}

void heidi_tellCity(int yourC)
{
	read_input();
	assert(yourC>0 && yourC<=C);

	if (yourC-1!=cityIndex)
		printf("WRONG ANSWER : You think Heidi is in city %2d, but she is in city %2d !\n",yourC,cityIndex+1);
	else	
		printf("ACCEPTED : You asked %2d questions and found the correct city!\n",questionCnt);
	exit(0);
}


