#ifndef TERRA_H_
#define TERRA_H_

enum{MAXC = 50, MAXP = 8, MAXV=3};

/* Returns the total number of cities in catalog */
int number_cities();

/* Returns the total number of properties*/
int number_properties();

/* Write the value (1, 2 or 3) of property P (1--8) of city C (1--50) into
   the array at position desc[C-1][P-1]
   */
void read_catalog(int desc[MAXC][MAXP]);

/*
 * returns '1' if property 'P' (1--8) has value 'V' (1--3) and '0' otherwise.
 * Your goal is to minimize the use of this function.
 */
int heidi_askQuestion(int P, int V);

/*
 * submit your answer to Heidi, that she is in city C (1--50) and end the program
 */
void heidi_tellCity(int C);

#endif 
