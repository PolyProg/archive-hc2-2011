#include <iostream>
#include <string>
#include <cstdio>
#include <fstream>
#include <vector>
#include <cstdlib>

using namespace std;

const int RES_ACCEPTED=0;
const int RES_PRESENTATION=1;
const int RES_WRONG=2;
const int RES_RT_ERROR=7;
const int RES_RT_REEVAL=11;

const bool PRINT=true;

bool checkFormat(string obt)
{
	for(size_t i=0;i<obt.length();++i)
	{
		if(i%2==0)
		{
			if(obt[i]<'a' || obt[i]>'z')
			{
				fprintf(stderr, "At %d: '%c', expected a-z\n",
						(signed)i, obt[i]);
				return false;
			}
		}
		else
		{
			if(obt[i]!='^' && obt[i]!='v' && obt[i]!='<' && obt[i]!='>')
			{
				fprintf(stderr, "At %d: '%c', expected ^v<>\n",
						(signed)i, obt[i]);
				return false;
			}
		}
	}
	return true;
}

void printstate(vector<string> const& state)
{
	if(!PRINT)
		return;

	for(size_t i=0;i<state.size();++i)
	{
		fprintf(stderr, "%s\n", state[i].c_str());
	}
}

bool move(vector<string> & state, char piece, char dir)
{
	vector<string> copy(state);

	//Remove all piece from state
	for(size_t i=0;i<state.size();++i)
	{
		for(size_t j=0;j<state[i].size();++j)
		{
			if(state[i][j]==piece)
			{
				state[i][j]='.';
				if(i==0 || j==0 || i==state.size()-1 || j==state[i].size()-1)
				{
					fprintf(stderr, "Furniture on border of map\n");
					return false;
				}
			}
		}
	}

	int XX=0, YY=0;
	switch(dir)
	{
		case 'v': XX=1; break;
		case '>': YY=1; break;
		case '^': XX=-1; break;
		case '<': YY=-1; break;
		default: fprintf(stderr, "Wrong direction\n"); return false;
	}

	//Move piece
	//Note that the room is surrounded by walls
	for(size_t i=1;i<state.size()-1;++i)
	{
		for(size_t j=1;j<state[i].size()-1;++j)
		{
			if(copy[i][j]==piece)
			{
				if(state[i+XX][j+YY]!='.')
				{
					fprintf(stderr, "Illegal move, collision with %c at %d %d\n",
							state[i+XX][j+YY], (signed)i, (signed)j);
					return false;
				}
				state[i+XX][j+YY]=piece;
			}
		}
	}

	return true;
}

bool compare(vector<string> const& state, vector<string> const& goal)
{
	for(size_t i=0;i<state.size();++i)
	{
		for(size_t j=0;j<state[i].size();++j)
		{
			if(goal[i][j]=='#')
			{
				if(state[i][j]!='#')
				{
					fprintf(stderr, "State lost wall %c %d %d\n",
							goal[i][j], (signed)i, (signed)j);
					return false;
				}
			}
			else if(goal[i][j]=='.')
			{
				if(state[i][j]!='.')
				{
					fprintf(stderr, "State: expected %c got %c at %d %d\n",
							goal[i][j], state[i][j], (signed)i, (signed)j);
					return false;
				}
			}
			else if(goal[i][j]=='?')
			{
				if(state[i][j]!='.' && state[i][j]<'a' && state[i][j]>'z')
				{
					fprintf(stderr, "State: expected %c got %c at %d %d\n",
							goal[i][j], state[i][j], (signed)i, (signed)j);
					return false;
				}
			}
			else if(goal[i][j]>='a' && goal[i][j]<='z')
			{
				if(state[i][j]!=goal[i][j])
				{
					fprintf(stderr, "State: expected %c got %c at %d %d\n",
							goal[i][j], state[i][j], (signed)i, (signed)j);
					return false;
				}
			}
			else
			{
				fprintf(stderr, "Illegal character in goal %c %d %d\n",
						goal[i][j], (signed)i, (signed)j);
				return false;
			}
		}
	}

	return true;
}
bool checkSolution(string obt, vector<string> & state, vector<string> const& goal)
{
	fprintf(stderr, "Start state:\n");
	printstate(state);

	for(size_t i=0;i<obt.size()/2;++i)
	{
		char piece = obt[2*i];
		char dir = obt[2*i+1];

		fprintf(stderr, "Moving %c %c:\n", piece, dir);

		if(!move(state, piece, dir))
		{
			fprintf(stderr, "Illegal move\n");
			return false;
		}
		printstate(state);
	}

	return compare(state, goal);
}

int main(int argc, char** argv)
{
	//Expected arguments:
	// 1. Real solution: one line per testcase: 0 of impossible 1 for possible
	// 2. Obtained solution
	// 3. Testcase number (1-10)
	// 4. Input
	// 5. Classify (current classification, should be lower/equal to 2)

	if(argc!=6)
	{
		fprintf(stderr, "Usage: %s expected obtained args input classify\n", argv[0]);
		fprintf(stderr, "Got %d args, expected 6\n", argc);
		return RES_RT_REEVAL;
	}

	fstream debug("/tmp/a.txt");
	for(int i=0;i<6;++i)
		debug<<argv[i]<<" ";
	debug<<endl;

	fstream expected(argv[1]);
	if(!expected)
	{
		fprintf(stderr, "Couldn't open 'expected' %s\n", argv[1]);
		perror("");
		return RES_RT_REEVAL;
	}
	fstream obtained(argv[2]);
	if(!obtained)
	{
		fprintf(stderr, "Couldn't open 'obtained' %s\n", argv[2]);
		perror("");
		return RES_RT_ERROR;
	}
	//Ignore 3rd argument
	fstream input(argv[4]);
	if(!input)
	{
		fprintf(stderr, "Couldn't open 'input' %s\n", argv[4]);
		perror("");
		return RES_RT_REEVAL;
	}
	int classify = atoi(argv[5]);

	if(classify > RES_WRONG)
	{
		fprintf(stderr, "Testcase already classified as %d\n", classify);
		return classify;
	}

	while(1)
	{
		//Read testcase
		int N, M, E;
		input>>N>>M>>E;
		if(input.fail())
			return RES_RT_REEVAL;
		if(N == 0 && M == 0 && E == 0)
		{
			return RES_ACCEPTED;
		}

		//Read solution
		int solvable;
		expected>>solvable;
		if(expected.fail())
			return RES_RT_ERROR;

		//Read input
		string s;
		getline(input, s);
		vector<string> start;
		vector<string> goal;
		for(int i=0;i<N;++i)
		{
			getline(input, s);
			if((signed)s.length()!=M)
				return RES_RT_REEVAL;
			start.push_back(s);
		}
		for(int i=0;i<N;++i)
		{
			getline(input, s);
			if((signed)s.length()!=M)
				return RES_RT_REEVAL;
			goal.push_back(s);
		}
		if(input.fail())
			return RES_RT_REEVAL;

		//Read obtained solution
		string obt;
		getline(obtained, obt);
		if(obtained.fail())
		{
			fprintf(stderr, "Failed to read obtained\n");
			return RES_WRONG;
		}
		if(obt=="Impossible")
		{
			if(!solvable)
				continue;
			else
			{
				fprintf(stderr, "This testcase is not impossible\n");
				return RES_WRONG;
			}
		}
		else
		{
			if(!solvable)
			{
				fprintf(stderr, "Warning: Attempting unsolvable testcase\n");
			}
			if((signed)obt.length()>2*E)
			{
				fprintf(stderr, "Obtained solution too long %d (max %d)\n",
						(signed)obt.length(), 2*E);
				return RES_WRONG;
			}
			if(obt.length()%2!=0)
			{
				fprintf(stderr, "Obtained solution length not even %d\n",
						(signed)obt.length());
				return RES_PRESENTATION;
			}
			if(!checkFormat(obt))
			{
				fprintf(stderr, "Obtained solution doesn't parse '%s'\n",
						obt.c_str());
				return RES_PRESENTATION;
			}
			if(!checkSolution(obt, start, goal))
			{
				fprintf(stderr, "Obtained solution wrong\n");
				return RES_WRONG;
			}
		}
	}

}
