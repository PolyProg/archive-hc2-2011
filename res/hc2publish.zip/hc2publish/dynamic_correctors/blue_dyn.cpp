#include <cstdio>
#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <cctype>
#include <fstream>
#include <cmath>
#include <cstdlib>

using namespace std;

const int RES_ACCEPTED=0;
const int RES_PRESENTATION=1;
const int RES_WRONG=2;
const int RES_RT_ERROR=7;
const int RES_RT_REEVAL=11;

const double MAX_ERR = 1.50001e-6;

//Remove spaces from a string
string remspace(string a)
{
	string s;
	for(size_t i=0;i<a.length();++i)
		if(isalpha(a[i]))
			s+=tolower(a[i]);
	return s;
}

int main(int argc, char** argv)
{
	//Expected arguments:
	// 1. Real solution: one line per testcase
	// 2. Obtained solution
	// 3. Testcase number (1-10)
	// 4. Input
	// 5. Classify (current classification, should be lower/equal to 2)

	if(argc!=6)
	{
		fprintf(stderr, "Usage: %s expected obtained args input classify\n", argv[0]);
		fprintf(stderr, "Got %d args, expected 6\n", argc);
		return RES_RT_REEVAL;
	}


	fstream expected(argv[1]);
	if(!expected)
	{
		fprintf(stderr, "Couldn't open 'expected' %s\n", argv[1]);
		perror("");
		return RES_RT_REEVAL;
	}
	fstream obtained(argv[2]);
	if(!obtained)
	{
		fprintf(stderr, "Couldn't open 'obtained' %s\n", argv[2]);
		perror("");
		return RES_RT_ERROR;
	}
	//int testcase = atoi(argv[3]);
	//Ignore 3rd argument
	fstream input(argv[4]);
	if(!input)
	{
		fprintf(stderr, "Couldn't open 'input' %s\n", argv[4]);
		perror("");
		return RES_RT_REEVAL;
	}
	int classify = atoi(argv[5]);

	if(classify > RES_WRONG)
	{
		fprintf(stderr, "Testcase already classified as %d\n", classify);
		return classify;
	}

	while(!expected.fail())
	{
		double want, got;
		expected>>want;
		obtained>>got;
		if(obtained.fail() && !expected.eof())
		{
			fprintf(stderr, "Not enough lines in obtained\n");
			return RES_WRONG;
		}

		if(fabs(want-got)>MAX_ERR)
		{
			fprintf(stderr, "Wrong answer: got %.7f  expected %.7f  diff %.7f  allowed %.7f\n",
					got, want, fabs(got-want), MAX_ERR);
			return RES_WRONG;
		}
	}
	if(!expected.eof())
	{
		fprintf(stderr, "Error while reading expected\n");
		return RES_RT_REEVAL;
	}
	if(!obtained.eof())
	{
		fprintf(stderr, "Too many lines in obtained\n");
		return RES_WRONG;
	}

	return RES_ACCEPTED;

}
