#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <cassert>
#include <queue>

using namespace std;

const size_t MAX_REACHED =  1000000;
const size_t ABORT_REACHED = 100000;

struct Coord
{
	signed char x, y;
	Coord():x(0),y(0){}
	Coord(int x, int y):x(x),y(y){}

	bool operator==(Coord const& rhs) const
	{
		return x==rhs.x and y==rhs.y;
	}
	bool operator<(Coord const& rhs) const
	{
		if(x<rhs.x)
			return true;
		if(rhs.x<x)
			return false;
		return y<rhs.y;

	}
	
	friend ostream & operator<<(ostream & out, Coord const& c)
	{
		out<<'['<<(int)c.x<<','<<(int)c.y<<']';
		return out;
	}

	void move(int dir)
	{
		switch(dir)
		{
			case 0: x++;break;
			case 1: y++;break;
			case 2: x--;break;
			case 3: y--;break;
			default:
					throw 1;

		}
	}
};

char DIRARR[]={'v', '>', '^', '<'};

struct State
{
	vector<Coord> coord;

	bool operator<(State const& rhs) const
	{
		if(coord.size() < rhs.coord.size())
			return true;
		if(coord.size() > rhs.coord.size())
			return false;

		for(size_t i=0;i<coord.size();++i)
		{
			if(coord[i] < rhs.coord[i])
				return true;
			if(rhs.coord[i] < coord[i])
				return false;
		}
		return false;
	}

	Coord& operator[](int i)
	{
		return coord[i];
	}


	friend ostream& operator<<(ostream & out, State const& rhs)
	{
		for(size_t i=0;i<rhs.coord.size();++i)
			out<<rhs.coord[i];
		return out;

	}

	bool operator==(State const& rhs) const
	{
		if(coord.size() != rhs.coord.size())
			return false;
		for(size_t i=0;i<coord.size();++i)
		{
			if(coord[i].x==0 && coord[i].y==0)
				continue;
			if(rhs.coord[i].x==0 && rhs.coord[i].y==0)
				continue;
			if(!(coord[i] == rhs.coord[i]))
				return false;
		}
		return true;
	}
};
struct Traceback
{
	int cost;
	char dir;
	char block;
	State state;

	Traceback():cost(-1),dir(' '){}
	Traceback(int c):cost(c),dir(' '){} //Implicit
	Traceback(int c, char dir, char block, State const& s):cost(c),dir(dir),block(block),state(s){}
};
struct Furn
{
	vector<string> shape;

	Furn(Furn const& rhs)
	{
		for(size_t i=0;i<rhs.shape.size();++i)
			shape.push_back(rhs.shape[i]);
	}
	Furn(){}
	Furn(vector<string> room, Coord origin, char c)
	{
		for(size_t i=origin.x;i<room.size();++i)
		{
			string s;
			size_t last=0;
			for(size_t j=origin.y, z=0;j<room[i].size();++j,z++)
			{
				if(room[i][j]==c)
					last=j;
			}
			for(size_t j=origin.y, z=0;j<=last;++j,z++)
			{
				if(room[i][j]==c)
					s.push_back(c);
				else
					s.push_back('.');
			}
			shape.push_back(s);
		}

		for(size_t i=shape.size()-1;i>=0;--i)
		{
			if(shape[i].size()==0)
				shape.pop_back();
			else
				break;
		}
	}

	bool collision(vector<string> room, Coord a)
	{
		for(size_t i=0;i<shape.size();++i)
		{
			for(size_t j=0;j<shape[i].size();++j)
			{
				if(shape[i][j]=='.')
					continue;
				if(room[i+a.x][j+a.y]!='#')
					continue;
				//cerr<<"Collision at "<<i<<" "<<j<<" - "<<i+a.x<<" "<<j+a.y<< shape[i][j]<<room[i+a.x][j+a.y]<<endl;
				return true;
			}
		}
		return false;
	}
	bool collision(Furn const& B, Coord a, Coord b)
	{
		for(size_t i=0;i<shape.size();++i)
		{
			for(size_t j=0;j<shape[i].size();++j)
			{
				if(shape[i][j]=='.')
					continue;
				int ii=i+a.x-b.x;
				int jj=j+a.y-b.y;
				if(ii<0 || (size_t)ii>=B.shape.size())
					continue;
				if(jj<0 || (size_t)jj>=B.shape[ii].size())
					continue;
				if(B.shape[ii][jj]=='.')
					continue;
				//cerr<<"Collision at "<<i<<" "<<j<<" - "<<ii<<" "<<jj<< shape[i][j]<<B.shape[ii][jj]<<endl;
				return true;
			}
		}
		return false;
	}
};
ostream & operator<<(ostream & out, vector<string> const& room)
{
	for(size_t i=0;i<room.size();++i)
	{
		for(size_t j=0;j<room[i].size();++j)
			out<<room[i][j];
		out<<endl;
	}
	return out;
}

Coord locate(vector<string> room, char c)
{
	int x=0, y=0;
	for(size_t i=0;i<room.size() && x==0;++i)
	{
		for(size_t j=0;j<room[i].size();++j)
		{
			if(room[i][j]==c)
			{
				x=i;
				break;
			}
		}
	}
	for(size_t j=0;room.size() && j<room[0].size() && y==0;++j)
	{
		for(size_t i=0;i<room.size();++i)
		{
			if(room[i][j]==c)
			{
				y=j;
				break;
			}
		}
	}
	return Coord(x,y);
}
int main(int argc, char** argv)
{
	while(1)
	{
		vector<string> room;
		vector<string> dest;
		int n, m, energy;
		cin>>n>>m>>energy;
		if((n==0 && m==0 && energy==0)||cin.fail())
			return 0;

		string s;
		getline(cin, s);
		//Read room
		for(int i=0;i<n;++i)
		{
			getline(cin, s);
			room.push_back(s);
		}
		//Read destination
		for(int i=0;i<n;++i)
		{
			getline(cin, s);
			for(size_t i=0;i<s.length();++i)
				if(s[i]=='?')
					s[i]='.';
				else if(s[i]=='.')
					s[i]='!';
			dest.push_back(s);
			//cerr<<s<<endl;
		}
		//Read floor of destination
		//cerr<<room<<"-"<<endl<<dest<<endl;
		//Locate pieces of furniture
		Coord zerozero;
		State icoord;
		State ocoord;
		State solvedstate;
		vector<Furn> shape;
		for(char i='a';i<='z';++i)
		{
			Coord c = locate(room, i);
			if(c==zerozero)
				continue;	
			icoord.coord.push_back(c);
			Furn a = Furn(room, c, i);
			shape.push_back(a);
			//cerr<<"Block "<<i<<" is at "<<c<<endl;
			//cerr<<a.shape;
			c = locate(dest, i);
			ocoord.coord.push_back(c); //may be zerozero
			//cerr<<"Dest  "<<i<<" is at "<<c<<endl;
		}
		Coord endc = locate(dest, '!');
		Furn enda = Furn(dest, endc, '!');

		map<State, Traceback> reached;
		bool solved=false;
		bool toomany=false;
		int lastlevel=0;
		queue<State> q;
		q.push(icoord);

		reached[icoord] = Traceback(0, '#', '#', icoord);
		while(!q.empty() && reached.size() <= MAX_REACHED)
		{
			State s = q.front();q.pop();
			//cerr<<"Popped: "<<s<<endl;
			if(!solved && s == ocoord)
			{
				bool ok=true;
				for(size_t z=0;ok&&z<shape.size();++z)
					if(shape[z].collision(enda, s[z], endc))
						ok=false;
				if(endc==zerozero)
					ok=true;
				if(ok)
				{
					//cerr<<"Solved! "<<reached[s].cost<<" "<<reached.size()<<" "<<s<<endl;
					solved=true;
					solvedstate = s;
				}
			}

			for(size_t i=0;i<shape.size();++i)
			{
				for(int j=0;j<4;++j)
				{
					State k(s);
					//cerr<<"Trying block "<<(char)(i+'a')<<" direction "<<j<<" ";
					k[i].move(j);
					if(reached.find(k)!=reached.end())
					{
						//cerr<<"Reached"<<endl;
						continue;
					}
					if(shape[i].collision(room, k[i]))
					{
						//cerr<<"Collision with room"<<endl;
						continue;
					}
					bool ok=true;
					for(size_t z=0;z<shape.size();++z)
					{
						if(z==i)
							continue;
						if(shape[i].collision(shape[z], k[i], k[z]))
						{
							//cerr<<"Collision with shape "<<(char)(z+'a')<<endl;
							ok=false;
							break;
						}
					}
					if(!ok)
						continue;
					//cerr<<"OK"<<endl;
					int level = reached[s].cost+1;
					if(level>lastlevel)
					{
						lastlevel=level;
						//cerr<<"At level "<<level<<" moves "<<reached.size()<<endl;
						if(level > energy)
							goto endofloop;
					}
					reached[k] = Traceback(level, DIRARR[j], i+'a', s);
					q.push(k);
				}
			}
		}

endofloop:

		//cerr<<"Reached "<<reached.size()<<endl;

		if(solved)
		{
			Traceback b = reached[solvedstate];
			//cerr<<"Sequence of moves:"<<endl;
			vector<string> moves;
			while(b.cost > 0)
			{
				string s;
				s.push_back(b.block);
				s.push_back(b.dir);
				moves.push_back(s);
				b = reached[b.state];
			}
			for(vector<string>::reverse_iterator i=moves.rbegin();i!=moves.rend();++i)
			{
				cout<<*i;
			}
			cout<<endl;
		}
		else if(toomany)
		{
			cout<<"Impossible"<<endl;
		}
		else
		{
			cout<<"Impossible"<<endl;
		}

	}
}
