#include <iostream>
#include <string>
#include <vector>

using namespace std;

int solve(string ss)
{
	if(ss.size()==0)
		return 0;

	vector<int> sumz;
	vector<int> sumo;
	int zeros=0, ones=0;
	for(int i=0;i<ss.size();++i)
	{
		if(ss[i]=='0')
			zeros++;
		else
			ones++;

		sumz.push_back(zeros);
		sumo.push_back(ones);
	}

	if(zeros%2 || ones%2)
		return -1;

	//Try to separate them in one cut
	if(sumz[(ss.size()-1)/2] == zeros/2 &&
			sumo[(ss.size()-1)/2] == ones/2)
		return 1;

	//Try in two cuts
	{
		int start=0, end=0;
		while(end < ss.size() && start<ss.size())
		{
			int diffzero = sumz[end]-sumz[start];
			int diffone = sumo[end]-sumo[start];

			if(diffzero < zeros/2)
				end++;
			else if(diffzero > zeros/2)
				start++;
			else if(diffone > ones/2)
				start++;
			else if(diffone < ones/2)
				end++;

			else if(diffzero == zeros/2 &&
					diffone == ones/2)
			{
				//cerr<<"Cut: "<<start<<" "<<end<<endl;
				return 2;
			}
			else
			{
				cerr<<"Error"<<endl;
				throw -3;
			}
		}
	}

	//Should never go here
	cerr<<"Error"<<endl;
	throw -2;
	return -2;
}

int main(int argc, char** argv)
{
	int ntc;
	cin>>ntc;
	for(int i=0;i<ntc;++i)
	{
		int sz;
		string s;

		cin>>sz>>s;
		int diff = sz-4*s.size();

		string ss="";
		if(diff>0)
		{
			for(int i=0;i<diff;++i)
				ss.push_back('0');
		}

		for(int i=0;i<s.size();++i)
		{
			int n=-1;
			if(s[i] >= '0' && s[i]<='9')
				n=s[i]-'0';
			else if(s[i] >= 'A' && s[i] <= 'F')
				n=s[i]-'A'+10;

			for(int i=8;i>0;i/=2)
			{
				if(n&i)
					ss.push_back('1');
				else
					ss.push_back('0');
			}

		}
		if(diff<0)
		{
			ss=ss.substr(-diff);
		}
		cout<<solve(ss)<<endl;
	}
}
