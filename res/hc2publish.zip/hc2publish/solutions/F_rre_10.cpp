#include "boomerang.h"
#include "math.h"

double f(double t)
{
	return sqrt( speedx(t)*speedx(t) + speedy(t)*speedy(t) );
}
//Gauss-Legendre rule with 3 points
int main(int argc, char** argv)
{
	double phi1 = 1/5.*(sqrt(15));
	double phi2 = -1/5.*(sqrt(15));
	double phi3 = 0;
	const double totaltime = 1;
	while(1)
	{
		int maxqueries = queries_left();
		double distance=0;
		int i;
		int qq = maxqueries/3;
		for(i=0;i<qq;++i)
		{
			double ti = i/(qq+0.);
			double tnext = (i+1)/(qq+0.);
			distance+= (tnext-ti)/2 * (
					5/9.*f(ti + (1/2.*(1 + phi1))*(tnext-ti)) +
					5/9.*f(ti + (1/2.*(1 + phi2))*(tnext-ti)) +
					8/9.*f(ti + (1/2.*(1 + phi3))*(tnext-ti))
					);
		}

		answer(distance/totaltime);
	}

	return 0; /*We will never get here*/
}
