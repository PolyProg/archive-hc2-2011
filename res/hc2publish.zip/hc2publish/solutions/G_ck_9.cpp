/* The Souvenir - Solution by Christian Kauth - 07/01/2011
 * -------------------------------------------------------
 * This is the easiest and shortest problem of HC2-2011. It requires nevertheless some insights and might keep you busy a while :)
 *
 * Let's suppose you know the the Ham-Sandwich theorem. In its restriction to 2D it states that any set of bicoloured points can be
 * split evenly for each colour by a straight line.
 * - If an odd number of pearls or rubies was counted, there is obviously no solution to the problem.
 * - If we lay out our garland as a straight line, 1 cut is sufficient according to the theorem (along the garland), but might be 
 *  illegal by the problem statement (beads cannot be split). The legal line would have to cut the garland exactly half way. This
 *  cut is balanced if and only if half of the beads of each type occur before the cut.
 * - If 1 cut is not enough, then we lay out our garland as a parabola.The straight line from the theorem cuts the parabola twice,
 *  hence we need two cuts. As a parabolic layout is always legal, we need never more than 2 cuts!
 *
 * In case you didn't know about this theorem, you could figure it out, right? ;) Or just try some examples by hand and realize that
 * you never need more than 2 cuts. The alternative would be to brute force it, first check if there is a solution with 1 cut, then
 * with 2, then 3 and so on and so forth. While this takes you more time to code, your code will be nevertheless fast enough, as your
 * algorithm will always find a solution no later than at the 2-cut trial!
 *
 * An additional difficulty was the hexadecimal format. It was only used to compress the input file and speed up reading, but turned
 * out to be riche source of penalties ;) (be careful with the orders of bits in numbers and groups of bits in strings)
 *
 * By the way, this code is a bit slow and will score 9 out of 10. I am sure you can beat this! :)
 */

#include "stdio.h"
#include "string.h"
#include <algorithm>
using namespace std;

#define MAXD 25000	// maximum number of hexadecimal digits
#define MAXB 100000	// maximum number of pieces in garland

int N;
char hex[MAXD];
int v[255];

void initialize()
{
	v['0'] = 0;	v['1'] = 1;	v['2'] = 2;	v['3'] = 3;
	v['4'] = 4;	v['5'] = 5; v['6'] = 6;	v['7'] = 7;
	v['8'] = 8;	v['9'] = 9;	v['A'] = 10;v['B'] = 11;
	v['C'] = 12;v['D'] = 13;v['E'] = 14;v['F'] = 15;
}

int min_cuts()
{
	int pearls(0), rubies(0), sign(1), b(0), d(0), val;
	
	// read bead code, make it right-to-left and add leading zeros
	scanf("%d %s", &N, hex);
	for (int i=0; i<strlen(hex)/2; i++)
		swap(hex[i],hex[strlen(hex)-1-i]);
	for (int i=strlen(hex); i<=(N-1)/4; i++)
		hex[i]='0';
	
	// odd number of pearls or rubies
	if (N%2) return -1;		
	
	// check if half of each bead sort occurs till the middle of the garland
	while (b<N)
	{
		//printf("%d - %d\n",d,v[hex[d]]);
		val=v[hex[d]];
		for (int i=0; i<4; i++)
		{
			(val%2) ? rubies += sign : pearls += sign;
			val >>= 1;
			if (++b == N/2)
				sign = -1;
			if (b>=N)
				break;		
		}
		d++;
	}
	if (rubies==0 && pearls==0) return 1;
	if (rubies%2 || pearls%2) return -1;
	return 2;
}
	
int main()
{
	int T;
	initialize();
	scanf("%d",&T);
	for (int i=0; i<T; i++)
		printf("%d\n",min_cuts());
	return 0;
}
