// Decrypts texts encrypted with the Vigenere algorithm
// The algorithm first tries to guess the key length with the
// index of coincidence method, and then guesses the key character
// by character by correlating the observed frequency with the
// ideal frequency.
//
// The first step is optional, since you can just brute-force the
// key length. But it is included here to show the performance of
// a fully-automated solution.
//
// The following solution solves 70% of the English and German
// testcases and 90% of the French testcases out of the box.
// The testcases that fail are the number 0 and 1, which have
// very short key length (1 and 2 respectively), and number 4 which
// was evil by design.
// By tinkering a bit, 90% is then easy to achieve. For the testcase
// 4, you need a bit of manual work and guess that the text
// is without 'e' :-).

#include <cstdio>
#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <cctype>
#include <cmath>

using namespace std;

double* langfreq;

double english[] = {
	0.08167, 0.01492, 0.02782, 0.04253, 0.12702, 0.02228, 0.02015, 0.06094,
	0.06966, 0.00153, 0.00772, 0.04025, 0.02406, 0.06749, 0.07507, 0.01929,
	0.00095, 0.05987, 0.06327, 0.09056, 0.02758, 0.00978, 0.02360, 0.00150,
	0.01974, 0.00074
};
double french[] = {
	0.08126, 0.00901, 0.03350, 0.03669, 0.17125, 0.01066, 0.00866, 0.00737,
	0.07589, 0.00545, 0.00049, 0.05456, 0.02968, 0.07095, 0.05388, 0.03021,
	0.01362, 0.06553, 0.07948, 0.07244, 0.06371, 0.01628, 0.00114, 0.00387,
	0.00308, 0.00136
};
double german[] = {
	0.06510, 0.01890, 0.03060, 0.05080, 0.17400, 0.01660, 0.03010, 0.04760,
	0.07550, 0.00270, 0.01210, 0.03440, 0.02530, 0.09780, 0.02510, 0.00790,
	0.00020, 0.07000, 0.07270, 0.06150, 0.04350, 0.00670, 0.01890, 0.00030,
	0.00040, 0.01130
};


//Remove spaces from a string
string remspace(string a)
{
	string s;
	for(size_t i=0;i<a.length();++i)
		if(isalpha(a[i]))
			s+=tolower(a[i]);
	return s;
}

//Count the number of occurences of each letter
vector<double> stats(string a)
{
	vector<double> v(26, 0);
	for(size_t i=0;i<a.length();++i)
		if(a[i]>='a' and a[i]<='z')
			v[a[i]-'a']++;
	return v;
}

//Compute the covariance between the two input vectors
double covariance(vector<double> v1, double* v2)
{
	//We could also compute the correlation here, but since
	//the variance of v1 doesn't change when applying the caesar cipher
	//and the variance of v2 is constant, we should get the same results

	//First normalize v1
	double sum=0;

	for(size_t i=0;i<v1.size();++i)
		sum+=v1[i];
	double mean = sum/v1.size();

	for(size_t i=0;i<v1.size();++i)
		v1[i]=(v1[i]-mean);

	//Then v2
	sum=0;

	for(size_t i=0;i<v1.size();++i)
		sum+=v2[i];
	mean = sum/v1.size();

	for(size_t i=0;i<v1.size();++i)
		v2[i]=(v2[i]-mean);

	//Compute covariance
	double cr=0;
	for(size_t i=0;i<v1.size();++i)
		cr+=v1[i]*v2[i];
	return cr/v1.size();
}

//Run the caesar cipher on the text a with the key k.
string caesar(string a, int k)
{
	while(k<0)
		k+=26;
	for(size_t i=0;i<a.length();++i)
		a[i] = (((a[i]-'a')+k)%26)+'a';
	return a;
}

//Transform the string s into a vector of k string. The ith string
//of the output contains all characters that are equal to i modulo k.
//If k is the correct key length, then all of the output strings are
//now encrypted just with a simple caesar cipher.
vector<string> explode(string s, int k)
{
	vector<string> t(k);
	for(size_t i=0;i<s.length();++i)
		t[i%k]+=s[i];
	return t;
}

//Invert the effect of explode.
string implode(vector<string> s)
{
	string t;
	int len=0;
	int k=s.size();
	for(size_t i=0;i<s.size();++i)
		len+=s[i].length();

	for(int i=0;i<len;++i)
		t+=s[i%k][i/k];
	return t;
}
//Try to guess the correct key for a string that was encrypted with the
//caesar algorithm.
//The input string is decrypted with the guesses key, and the guessed
//key is returned.
string uncaesar(string &t)
{
	double bestcorr=-2;
	int bestcorri=0;
	//Find best covariance
	for(int k=0;k<26;++k)
	{
		string c = caesar(t, k);
		double cc = covariance(stats(c), langfreq);
		if(cc>=bestcorr)
		{
			bestcorr=cc;
			bestcorri=k;
		}
	}

	//Decrypt
	t=caesar(t, bestcorri);

	//Prepare key
	string ret;
	ret+=bestcorri+'a';
	return ret;
}

//Negate the key (z->a, y->b, x->c etc)
string negkey(string key)
{
	for(size_t i=0;i<key.length();++i)
	{
		int a = key[i]-'a';
		a= (-a+26)%26;
		key[i]=a+'a';
	}
	return key;
}
//Given a decrypted plaintext without spaces and the original
//ciphertext with spaces, we add the spaces again to the plaintext.
string addspaces(string tt, string orig)
{
	string ret;

	for(size_t i=0,j=0;i<orig.size();++i)
	{
		if(isalnum(orig[i]))
		{
			ret.push_back(tt[j]);
			j++;
		}
		else
			ret.push_back(orig[i]);
	}

	return ret;
}
//Compute the index of coincidence of the string given as input
//The index of coincidence is close to 1/26=0.38 for a random string, but
// is close to 0.65 for an English text (even higher for French and German)
// It is not affected by substitution, which is very important here, since we
// are computing this on the ciphertext.
// If we guessed the key incorrectly, we make the assumption that str is
// a random string (which is not exactly the case here), so we get a low
// index. If we guessed the key length correctly, the index of coincidence
// will be very close to that of the language.
double indexcoic(string str)
{
	vector<double> s = stats(str);

	int n = str.size();

	double sum=0;
	for(size_t i=0;i<s.size();++i)
		sum += s[i]*(s[i]-1)/(n*(n-1));

	return sum;
}

//Guess the key length based only on the ciphertext
//We return the key length that has the highest index of
//coincidence.
//We use the geometric mean here (instead of the arithmetic),
// which is better suited to the problem.
// (If we use the arithmetic mean, then we only solve 60% of
// the German testcases; the harmonic mean performs the same as
// the geometric mean).
//
// Note that this works very poorly if the correct key length is small.
int guesskeylen(string t)
{
	vector<double> ic(22, 0);
	//Index of coincidence
	for(int keylen=1;keylen<=20;++keylen)
	{
		vector<string> exs = explode(t, keylen);
		//Geometric mean of each fragment
		double sum=1;
		for(size_t j=0;j<exs.size();++j)
		{
			sum*=indexcoic(exs[j]);
		}
		sum = pow(sum, 1./keylen);
		ic[keylen]=sum;
	}
	//We take the maximum index of coincidence as the guess of the key length
	double maxic=0;
	int maxkl=0;
	for(int keylen=1;keylen<=20;++keylen)
		if(ic[keylen]>maxic)
		{
			maxic = ic[keylen];
			maxkl = keylen;
		}

	return maxkl;
}

int main(int argc, char** argv)
{
	while(1)
	{
		//Read a line of input
		int tc;
		string lang;
		string t;
		cin>>tc>>lang;
		getline(cin, t);
		if(cin.eof())
			return 0;
		if(cin.fail())
			return 1;

		//Detect language
		if(lang=="e")
			langfreq = english;
		else if(lang=="f")
			langfreq = french;
		else if(lang=="d")
			langfreq=german;
		else
			return 2;

		//Remove spaces
		string origtext = t;
		t = remspace(t);

		//Guess key length
		int keylen = guesskeylen(t);

		//Each fragment of text should now only be encrypted with the caesar algorithm
		vector<string> exs = explode(t, keylen);
		string key;
		for(int i=0;i<keylen;++i)
		{
			key+= uncaesar(exs[i]);
		}
		string tt=implode(exs);

		//Add spaces again (for legibility)
		tt = addspaces(tt, origtext);

		//Debug
		//cerr<<tc<<" "<<lang<<"  Key length: "<<keylen<<" Key: "<<negkey(key)<<endl;

		//Output
		cout<<tc<<" "<<lang<<tt<<endl;
	}

	return 0;
}
