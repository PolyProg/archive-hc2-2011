
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

struct Coord
{
	Coord(double x, double y, double z):x(x),y(y),z(z){}
	Coord():x(0),y(0),z(0){}
	double x, y, z;

	double get(int axis) const
	{
		if(axis==0)
			return x;
		else if(axis==1)
			return y;
		else
			return z;
	}

	double distance2(Coord const& rhs) const
	{
		double xx = (x-rhs.x);
		double yy = (y-rhs.y);
		double zz = (z-rhs.z);
		return xx*xx + yy*yy + zz*zz;
	}
	double distanceaxis2(Coord const& rhs, int axis) const
	{
		double xx = (x-rhs.x);
		double yy = (y-rhs.y);
		double zz = (z-rhs.z);

		if(axis==0)
			return xx*xx;
		else if(axis==1)
			return yy*yy;
		else
			return zz*zz;
	}
};
struct Object
{
	Coord pos;
	Coord speed;
	double r;

	Object(double x, double y, double z,
			double dx, double dy, double dz, double r):
		pos(x, y, z), speed(dx, dy, dz), r(r)
	{};

	Coord atTime(int i) const
	{
		Coord ret(
				pos.x + i*speed.x,
				pos.y + i*speed.y,
				pos.z + i*speed.z);
		return ret;
	}
};

int nodeidx=0;

struct Node
{
	Node* leftChild;
	Node* rightChild;
	Coord value;
	int axis;

	Node():leftChild(NULL),rightChild(NULL){};

	void clear()
	{
		nodeidx=0;
	}
};

Node nodepool[50020];

Node* allocnode()
{
	return &(nodepool[nodeidx++]);
}

bool OrderX(const Coord& lhs, const Coord& rhs)
{
	return lhs.x < rhs.x;
}
bool OrderY(const Coord& lhs, const Coord& rhs)
{
	return lhs.y < rhs.y;
}
bool OrderZ(const Coord& lhs, const Coord& rhs)
{
	return lhs.z < rhs.z;
}

Node* kdTree(vector<Coord>& points, int start, int end, int depth=0)
{
	if(start>=end)
		return NULL;

	int axis = depth%3; // 3  dimensions

	int median = start + (end-start)/2;
	if(axis==0)
		nth_element(points.begin()+start, points.begin()+median, points.begin()+end, OrderX);
	else if(axis==1)
		nth_element(points.begin()+start, points.begin()+median, points.begin()+end, OrderY);
	else
		nth_element(points.begin()+start, points.begin()+median, points.begin()+end, OrderZ);

	Node* newnode = allocnode();

	newnode->value = points[median];
	newnode->leftChild = kdTree(points, start, median, depth+1);
	newnode->rightChild = kdTree(points, median+1, end, depth+1);
	newnode->axis = axis;

	return newnode;
}

Node* child_near(Node* here, Coord const& point)
{
	if(point.get(here->axis) > here->value.get(here->axis))
		return here->rightChild;
	else
		return here->leftChild;
}
Node* other_child(Node* here, Node* a, Coord const& point)
{
	if(a == here->leftChild)
		return here->rightChild;
	return here->leftChild;
}
Node* kdSearch(Node* here, Coord const& point, Node* best)
{
	if(here == NULL)
		return best;
	if(best == NULL)
		return here;

	if(point.distance2(here->value) < point.distance2(best->value))
	{
		best=here;
	}

	//Determine the nearest neighbour to point
	Node* child = child_near(here, point);
	best = kdSearch(child, point, best);

	if( point.distanceaxis2(here->value, here->axis) < point.distance2(best->value))
	{
		Node* ochild = other_child(here, child, point);
		best = kdSearch(ochild, point, best);
	}

	return best;
}


int main(int argc, char** argv)
{
	int N;
	vector<Object> bullets;
	scanf("%d", &N);
	for(int i=0;i<N;++i)
	{
		double x, y, z, dx, dy, dz;
		scanf("%lf %lf %lf %lf %lf %lf", &x, &y, &z, &dx, &dy, &dz);
		bullets.push_back(Object(x, y, z, dx, dy, dz, 1.0));
	}
	int M;
	vector<Object> ships;
	scanf("%d", &M);
	for(int i=0;i<M;++i)
	{
		double x, y, z, dx, dy, dz, r;
		scanf("%lf %lf %lf %lf %lf %lf %lf", &x, &y, &z, &dx, &dy, &dz, &r);
		ships.push_back(Object(x, y, z, dx, dy, dz, r));
	}
	int T;
	scanf("%d", &T);

	vector<int> shipdead(M, -1);
	//Compute collisions at all time units
	for(int t=0;t<T;++t)
	{
		//Coords of bullets
		vector<Coord> currentbullets;
		for(int i=0;i<N;++i)
			currentbullets.push_back(bullets[i].atTime(t));

		Node* root = kdTree(currentbullets, 0, N, 0);

		for(int s=0;s<M;++s)
		{
			if(shipdead[s]!=-1)
				continue;

			Coord shipnow = ships[s].atTime(t);
			Node* near = kdSearch(root, shipnow, root);
			if(near==NULL)
				throw 1;
			if(shipnow.distance2(near->value) < (ships[s].r+1)*(ships[s].r+1))
			{
				//double err = fabs( shipnow.distance2(near->value) -  (ships[s].r+1)*(ships[s].r+1));
				//if(err<error)
				//	error=err;
				shipdead[s]=t;
			}
		}
		root->clear();
		//delete root;
	}

	//Print result
	for(int i=0;i<M;++i)
	{
		if(i!=0)
			printf(" ");
		printf("%d", shipdead[i]);
	}
	printf("\n");
	//fprintf(stderr, "Precision required: %lf\n", error);

	return 0;
}
