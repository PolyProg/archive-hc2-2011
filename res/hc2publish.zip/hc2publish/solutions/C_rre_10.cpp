#include <iostream>
#include <vector>
#include <queue>
#include <stack>
#include <set>
#include <cstdlib>
#include <cassert>
using namespace std;

bool log=false;

int min(int a, int b)
{
	if(a<b)
		return a;
	return b;
}
int max(int a, int b)
{
	if(a>b)
		return a;
	return b;
}

class Tarjan
{
private:
	int cindex;
	int ccompindex;

	vector<vector<int> >* E;
	vector<int>  index;
	vector<int>  lowlink;
	stack<int>  S;
	vector<bool> onstack;

public:
	vector<int>  compindex;

	void start(vector<vector<int> > *edges)
	{
		E = edges;
		index = vector<int>(E->size());
		lowlink = vector<int>(E->size());
		compindex = vector<int>(E->size());
		cindex=0;
		ccompindex=0;
		onstack = vector<bool>(E->size(), false);

		for(int i=0;i<E->size();++i)
		{
		  if(index[i]==0)
			tarjan(i);
		}

	}
private:
	void tarjan(int v)
	{
	  index[v]=cindex;
	  lowlink[v]=cindex;
	  cindex++;
	  S.push(v); onstack[v]=1;
	  for(vector<int>::iterator i=(*E)[v].begin();i!=(*E)[v].end();++i)
	  {
		int vp=*i;
		if(index[vp]==0)
		{
		  tarjan(vp);
		  lowlink[v] = min(lowlink[v], lowlink[vp]);
		}
		else if(onstack[vp])
		{
		  lowlink[v] = min(lowlink[v], index[vp]);
		}
	  }
	  if(lowlink[v]==index[v])
	  {
		ccompindex++;
		//cerr<<"Strong connected component: "<<endl;
		while(!S.empty())
		{
		  int vp=S.top();S.pop();onstack[vp]=0;
		  //cerr<<vp<<" "<<endl;
		  compindex[vp]=ccompindex;
		  if(vp==v)
			break;
		}
	  }
	}

};

class TwoSat
{
	private:
		vector<vector<int> > E;

	public:
	TwoSat(int variables)
	{
		E = vector<vector<int> >(variables*2);
	}

	void addclause(int a, int b)
	{
		if(log)
			cerr<<"CLAUSE "<<a<<" "<<b<<" "<<0<<endl;
		//Add a 2-SAT clause  1 = a or b
		//Use negative indexes for negation

		//Transform into implication
		// a or b  is the same as -a => b   and  -b => a
		addimplication(-a, b);
		addimplication(-b, a);
	}

	bool sat()
	{
		//Are the clauses satisfiable?

		Tarjan tj;
		tj.start(&E);

		//Check that all variables are in two different strongly
		//connected components
		for(int i=0;i<E.size();i+=2)
		{
			if( tj.compindex[i] == tj.compindex[i+1] )
				return false;
			//cerr<<tj.compindex[i]<<tj.compindex[i+1]<<endl;
		}
		return true;
	}

	private:
	void addimplication(int a, int b)
	{
		int aa = toCoord(a);
		int bb = toCoord(b);

		E[aa].push_back(bb);
		//cerr<<"add: "<<aa<<bb<<endl;
	}

	int toCoord(int a)
	{
		int cc;
		if(a>0)
			cc=2*a-2;
		else if(a<0)
			cc=-2*a-1;
		else
		{
			cerr<<"Invalid CNF clause"<<endl;
			exit(-5);
		}

		if(cc<0 || cc>=E.size())
		{
			cerr<<"Invalid CNF clause"<<endl;
			exit(-4);
		}

		return cc;
	}

};

int street(int S, bool dir, int a, int s)
{
	S++;
	if(dir)
		S=-S;
	return S;
}
int avenue(int A, bool dir, int a, int s)
{
	A+=s;
	A++;
	if(dir)
		A=-A;

	return A;
}
bool trysolve(vector<pair<int, int> > const& sights, int test, int a, int s)
{
	TwoSat ts((a+s)*2);

	//log=true;

	// We need at least one road from sight i to sight i+1
	for(int i=0;i<test-1;++i)
	{
		bool samex = (sights[i].first == sights[i+1].first);
		bool samey = (sights[i].second == sights[i+1].second);

		bool dx = sights[i].first > sights[i+1].first;
		bool dy = sights[i].second > sights[i+1].second;

		//cerr<<"Street from "<<sights[i].first<<" "<<sights[i].second<<" "<<sights[i+1].first<<" "<<sights[i+1].second<<endl;
		if(samex && samey)
			continue;  //Nothing to do
		else if(samex)
		{
			int a = street(sights[i].first, dy, a, s);
			ts.addclause(a, a);
		}
		else if(samey)
		{
			int a = avenue(sights[i].second, dx, a, s);
			ts.addclause(a, a);
		}
		else
		{
			//First option: first vertical, then horizontal
			int a = street(sights[i].first,    dy, a, s);
			int b = avenue(sights[i+1].second, dx, a, s);

			//Second option: first horizontal, then vertical
			int c = avenue(sights[i].second,  dx, a, s);
			int d = street(sights[i+1].first, dy, a, s);

			//Equation is (a AND b) OR (c AND d) = (a OR c) AND (a OR d) AND (b OR c) AND (b OR d)
			ts.addclause(a, c);
			ts.addclause(a, d);
			ts.addclause(b, c);
			ts.addclause(b, d);
		}
	}

	return ts.sat();
}

int testcase(int n, int a, int s)
{
	vector<pair<int, int> > sights;

	for(int i=0;i<n;++i)
	{
		int x, y;
		cin>>x>>y;
		sights.push_back(pair<int,int>(x-1, y-1));
	}

	//Binary search
	int mins=1, maxs=n;

	while(mins != maxs)
	{
		int test = (mins+1+maxs)/2;

		//cerr<<"Try solve "<<test<<" "<<mins<<"-"<<maxs<<endl;
		bool res = trysolve(sights, test, a, s);
		if(res)
		{
			//cerr<<"SOLVED"<<endl;
			mins=test;
		}
		else
		{
			maxs=test-1;
			//cerr<<"NOT SOLVED"<<endl;
		}
	}

	//log=true;
	//cerr<<"Verify solution "<<mins<<endl;
	assert(trysolve(sights, mins, a, s));
	log=false;
	assert(mins==n || !trysolve(sights, mins+1, a, s));

	return mins;
}

int main()
{
	int a, s, n;

	while(1)
	{
		cin>>s>>a>>n;

		if(a==0 && s==0 && n==0)
			return 0;

		cout<<testcase(n, a, s)<<endl;
	}
}
