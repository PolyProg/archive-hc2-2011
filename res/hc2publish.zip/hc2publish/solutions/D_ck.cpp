/* Vigenere - Solution by Christian Kauth - 11/01/2011
 * ---------------------------------------------------
 * 
 * The idea is to find first the length of the key, then the letters of the key
 * - If the cypher contains repetitions, there is a good chance that they are due to repetitions in the plain text!
 *   Hence the distance between the repetitions in the cypher must be a multiple of the length of the key.
 * - Once the length is known, split the cypher into subcyphers, so that each subcypher is encoded by one single letter.
 *   Frequency analysis combined to a least squares distance to the original language then solves the problem.
 *
 * Let's make the computer perform the boring and painful analyses, but let's interprete the results ourselves!
 * Here is an interactive program that helps you to solve the cypher yourself :)
 * - First you are asked for the testcase index and the language enter 'a b' with 'a' in [0;9] and 'b' in {e,d,f}
 * - The the PC performs a repetition analysis and asks you about your choice on the key-length. Enter the number
 * - Next for each of the letters of the key, a frequency analysis is performed and the PC indicates the squared
 *   distance to the real language for each possible shift. You must decide which letter you find most probable.
 *
 * A special line accounting for a special plaintext without 'e' is to be uncommented for the last test-case
 *
 * Too long input might make this code fail. So just truncate it, find the key and then decrypt the whole text with 
 * that key. Alternatively, find the bug and fix the code, but the first option was just so much more appealing ;)
 */
 
#include<iostream>
#include<string>
#include<iomanip>
#include<vector>
#include<cmath>
#include<fstream>
using namespace std;

#define MAXKEY 20
#define ENGLISH 0
#define GERMAN 1
#define FRENCH 2
#define INF 10000.0

const double realProb[3][26] = {{8.17, 1.49, 2.78, 4.25, 12.70, 2.23, 2.02, 6.09, 6.97, 0.15, 0.77, 4.03, 2.41, 6.75, 7.51, 1.93, 0.10, 5.99, 6.33, 9.06, 2.76, 0.98, 2.36, 0.15, 1.97, 0.07},{6.51, 1.89, 3.06, 5.08, 17.40, 1.66, 3.01, 4.76, 7.55, 0.27, 1.21, 3.44, 2.53, 9.78, 2.51, 0.79, 0.02, 7.00, 7.27, 6.15, 4.35, 0.67, 1.89, 0.03, 0.04, 1.13},{8.13, 0.90, 3.35, 3.67, 17.125, 1.07, 0.87, 0.74, 7.59, 0.55, 0.05, 5.46, 2.97, 7.10, 5.39, 3.02, 1.36, 6.55, 7.95, 7.24, 6.37, 1.63, 0.11, 0.39, 0.31, 0.14}};

string cypher;								// the encrypted text
int N;										// the length of the encrypted text
int keyLength[MAXKEY+1][MAXKEY+1];			// probable key length j found from a repetition of length i
int L;										// key length as indicated by user
string subCypher[MAXKEY+1];					// the cypher, decomposed into goups encoded by the same letter
string key;									// the key as indicated by the user
string fi;									// file index
string lang;								// language
int langi;									// index of the language

// reads cypher and removes spaces
void read_cypher()
{
	cout<<"Testcase and Language : "; cin>>fi>>lang; cout<<endl;
	string fileName(fi); fileName += "-"; fileName += lang; fileName += ".txt";
	ifstream fin(fileName.c_str());
	getline(fin,cypher);
	fin.close();
	if (lang=="e") langi=ENGLISH; else if (lang=="d") langi=GERMAN; else langi=FRENCH;
	
	for (int i = cypher.size()-1; i>=0; i--)
		if (cypher[i]==' ')
			cypher.replace(i,cypher.size()-i,cypher.substr(i+1,cypher.size()-i-1));	
	N=cypher.size();
}

// finds repetitions in cypher
void find_repetitions()
{
	int l;
	for (int a=0; a < N; a++)
		for (int b=a+1; b < N; b++)
		{
			l=0; while (b+l<N && l<=20 && cypher[a+l]==cypher[b+l]) l++;
			for (int i=1; i<=20; i++)
				if ((b-a)%i==0)
					keyLength[l][i]++;
		}
		
	cout<<"     ";
	for (int i=1; i<=20; i++)
		cout<<setw(4)<<i;
		
	for (int i=2; i<=MAXKEY; i++)
	{
		cout<<endl<<setw(2)<<i<<" : ";
		for (int j=1; j<=MAXKEY; j++)
			cout<<setw(4)<<keyLength[i][j];
	}	
	cout<<endl;
}

// asks the user for the length of the key and decomposes the cypher accordingly
void get_keyLength()
{
	cout<<endl<<"Enter the probable key-length : "<<endl;
	cin>>L;
	for (int i=0; i<N; i++)
		subCypher[i%L].push_back(cypher[i]);
}

// performs a frequency analysis on subCypher s and asks user for key-letter
void frequency_analysis(int s)
{
	vector<double> prob(26,0);
	vector<double> error(26,0);
	for (unsigned int i=0; i<subCypher[s].size(); i++)
		prob[subCypher[s][i]-'A'] += 100.0/subCypher[s].size();

	cout<<endl<<"real : ";
	for (int j=0; j<26; j++)
		cout<<setw(3)<<floor(realProb[langi][j]+0.5);
		
	for (int i=0; i<26; i++)
		for (int j=0; j<26; j++)
			//if (j!=4)			// in case there is no 'E' in the text ;)
				error[i] += pow(prob[(j+i)%26]-realProb[langi][j],2.0);
	
	for (int i=0; i<26; i++)
	{
		int b=0;
		for (int j=1; j<26; j++)
			if (error[j]<error[b])
				b=j;
		cout<<endl<<"   "<<char(b+'A')<<" : ";
		for (int j=0; j<26; j++)
			cout<<setw(3)<<floor(prob[(j+b)%26]+0.5);
		cout<<" - "<<setw(5)<<floor(error[b]+0.5)<<"  "<<char(b+'A');
		error[b] = INF;
	}
	cout<<endl;
	
	char letter;
	cout<<"What's your guess on the key-letter "<<s<<" ? ";
	cin>>letter;
	key.push_back(letter);
}

// outputs the plain-text
void output_plainText()
{
	cout<<"With the key '"<<key<<"', the plain-text is :"<<endl;
	for (int i=0; i<N; i++)
		cout<<char(((cypher[i]-key[i%L]+26)%26)+'A');
	cout<<endl;
	
	string fileName(fi); fileName += "-"; fileName += lang; fileName += ".out";
	ofstream fout(fileName.c_str());
	fout<<"With the key '"<<key<<"', the plain-text is :"<<endl;
	for (int i=0; i<N; i++)
		fout<<char(((cypher[i]-key[i%L]+26)%26)+'A');
	fout<<endl;
	fout.close();	
}		
	
int main()
{
	read_cypher();
	find_repetitions();
	get_keyLength();
	for (int i=0; i<L; i++)
		frequency_analysis(i);
	output_plainText();
	return 0;
}
