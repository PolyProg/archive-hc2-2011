/* 
 * Massively Multiplayer Shoot 'em up - Solution by Christian Kauth - 16/01/2011
 * -----------------------------------------------------------------------------
 *
 * We have two sets of spheres - ships and bullets - and we are to find for each ship the time it first intersects with a bullet.
 * Iterating through every combination (ship,bullet) for all times leads to O(TN²) complexity, which is too slow.
 *
 * To speed the process up, we can project the bullets' positions onto the 3 dimension axes and sort them (O(Nlog(N))). Then we look
 * for intersections of these projections with the ships' projections via binary_search. Finally we have to check in detail whether
 * any of these potentially dangerous bullets hits the ship. For this we choose the dimension with least dangerous bullets and test
 * them all. Although this runs also in quadratic time, note that the number of ships and bullets involved is reduced significantly!
 * Ships that were hit shall not appear anymore in future computations!
 *
 * The running time of this solution is O(TN(log(N)+?)) with ? sufficiently small.
 *
 * kd-trees are the alternative
 */

#include<stdio.h>
#include<algorithm>
#include<map>
#include<cmath>
#include<vector>
using namespace std;

#define NEVER -1		// suffers never a collision
#define MAXB 100000		// maximum number of bullets
#define MAXS 100000		// maximum number of ships
#define MAXDIM 3		// number of dimensions

struct TSphere
{
	double x[MAXDIM];	// position
	double v[MAXDIM];	// velocity
	double r;			// radius
	int t;				// collision time
};

struct TProjection
{
	double pos;			// position on chosen dimension
	int id;				// identifier of the sphere
};

int B, S;											// bullets and ships
int T;												// simulation time
TSphere bullets[MAXB], ships[MAXS];					// of all bullets and ships
vector<vector<TProjection> > proj(MAXDIM);			// projection of all bullets' centers onto the 3 dimension axes
int ls[MAXS];										// set of all living ships
int ns;												// living ships	

bool mySortComp (TProjection i,TProjection j) { return (i.pos<j.pos); }
bool mySearchLowComp (TProjection i, double value) { return (i.pos<value); }
bool mySearchUpComp (double value, TProjection i) { return (value<i.pos); }

void read_case()						// O(N)
{
	// read bullets
	scanf("%d",&B);
	for (int i=0; i<B; i++)
	{
		scanf("%lf %lf %lf %lf %lf %lf",&bullets[i].x[0],&bullets[i].x[1],&bullets[i].x[2],&bullets[i].v[0],&bullets[i].v[1],&bullets[i].v[2]);
		bullets[i].r = 1.0;
		bullets[i].t = NEVER;
	}
	// read ships
	scanf("%d",&S);
	for (int i=0; i<S; i++)
	{
		scanf("%lf %lf %lf %lf %lf %lf %lf",&ships[i].x[0],&ships[i].x[1],&ships[i].x[2],&ships[i].v[0],&ships[i].v[1],&ships[i].v[2],&ships[i].r);
		ships[i].t = NEVER;
	}
	// read time
	scanf("%d",&T);
	// initialize living spheres
	for (int i=0; i<S; i++)
		ls[i] = i;
	ns=S;
	proj[0].resize(B); proj[1].resize(B); proj[2].resize(B);	
}

int remaining_ships()					// O(N)
{
	int cnt(0);
	for (int i=0; i<ns-cnt; i++)
		if (ships[ls[i]].t != NEVER)
			swap(ls[i--],ls[ns-1-cnt++]);
	return ns-cnt;
}		

void project_bullets()					// O(Nlog(N))
{
	for (int d=0; d<MAXDIM; d++)
	{
		for (int i=0; i<B; i++)
		{
			proj[d][i].pos = bullets[i].x[d];	
			proj[d][i].id  = i;
		}	
		sort(proj[d].begin(),proj[d].end(),mySortComp);
	}
}

void update_positions()					// O(N)
{
	for (int d=0; d<MAXDIM; d++)
	{
		for (int i=0; i<B; i++)
			bullets[i].x[d] += bullets[i].v[d];
		for (int i=0; i<ns; i++)
			ships[ls[i]].x[d] += ships[ls[i]].v[d];
	}
}
	
bool collision_check(int si, int bi)	// O(1)
{
	double d(0);
	for (int i=0; i<MAXDIM; i++)
		d += (ships[si].x[i]-bullets[bi].x[i]) * (ships[si].x[i]-bullets[bi].x[i]);
	return d <= (ships[si].r+1.0) * (ships[si].r+1.0);
}

void find_collisions(int t)				// O(N(log(N)+?))
{
	vector<TProjection>::iterator low, up;
	int iLow[MAXDIM], iUp[MAXDIM];
	int d;
	
	for (int i=0; i<ns; i++)
	{
		// find dangerous bullets in each dimension
		for (d=0; d<MAXDIM; d++)
		{
			low = lower_bound (proj[d].begin(), proj[d].end(), ships[ls[i]].x[d]-ships[ls[i]].r-1.0, mySearchLowComp);
			up  = upper_bound (proj[d].begin(), proj[d].end(), ships[ls[i]].x[d]+ships[ls[i]].r+1.0, mySearchUpComp);
			iLow[d] = int(low-proj[d].begin()); iLow[d]--; if (iLow[d]<0) iLow[d]=0;
			iUp[d]  = int(up-proj[d].begin());  iUp[d]++;  if (iUp[d]>=B) iUp[d]=B-1;
		}
		
		// check for collision with dangerous bullets in smallest set
		int delta[MAXDIM]={iUp[0]-iLow[0],iUp[1]-iLow[1],iUp[2]-iLow[2]};
		d = (delta[0]<=delta[1] && delta[0]<=delta[2]) ? 0 : (delta[1]<=delta[2] && delta[1]<=delta[0])	? 1 : 2;
		for (int j=iLow[d]; j<=iUp[d]; j++)
			if (collision_check(ls[i],proj[d][j].id))
			{
				ships[ls[i]].t = t;
				break;
			}								
	}
}

void output()							// O(N)
{
	printf("%d",ships[0].t);
	for (int i=1; i<S; i++)
		printf(" %d",ships[i].t);
	printf("\n");
}

int main()
{	
	read_case();
	project_bullets();
	find_collisions(0);

	for (int i=1; i<T; i++)
	{
		ns = remaining_ships();
		update_positions();
		project_bullets();
		find_collisions(i);
	}

	output();
	return 0;
}