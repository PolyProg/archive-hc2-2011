/* Into the blue - Solution by Christian Kauth - 15/01/2011
 * --------------------------------------------------------
 *
 * A pinch of 'greedy' and a certain dose of dynamic programming lead to a 100% solution.
 * Cheesy brute forcing (choosing the most efficient of all N^(N-2) spanning trees to the 
 * complete graph (cf. Cayley's formula)) is awarded 40% for the pain of implementation!
 *
 * - THE GREEDY OBSERVATION is that the earlier two sub-clouds are merged, the lesser their influence on the final security!
 *   Hence sort the initial securities (let's say in increasing order) and you can be sure that grouping exclusively neighbour 
 *   sub-clouds can be optimal!
 *   
 * - THE DP STATES can be defined in a 3-D space. Let's write secu[i][j][k] the best possible security for a cloud grouping offices 
 *   'i' to 'j' at a cost of 'k'.
 *
 * - THE DP TRANSITION can be stated as: What was the last connection made to get cloud [i][i+s][k] optimal? A cloud [i;i+s] is formed
 *   by any connection between sub-clouds [i;i+j]&[i+j+1,i+s], with 0<=j<s. Note that although a cloud of 8 could be split as
 *   1&7, 2&6, 3&5, 4&4, 5&3, 6&2, 7&1, you would always prefer 7&1 to 1&7, 6&2 to 2&6 and 5&3 to 3&5 due to the greedy insight! Hence
 *   it is sufficient to have s/2<=j<s. Finally the cost of the composed cloud is the sum of the costs of each sub-cloud plus 's'.
 *
 * - AN OPTIMIZATION is to realize that the worst cost comes from a linear grouping at an expense of N*(N+1)/2 and the best from a binary
 *   balanced tree at expense N*log2(N). So there is no need to sweep over all costs at each stage.
 *
 * - THE ALGORITHM is of complexity O(N⁷) but the constant is very small!
 *
 *	for (int s=1; s<N; s++)
 *		for (int i=0; i<N-s; i++)
 *			for (int j=s/2; j<s; j++)
 *				for (int cl=N_log2_N[j+1]; cl<intSum[j+1]; cl++)
 *					if (secu[i][i+j][cl]!=NONE)
 *						for (int cr=N_log2_N[s-j]; cr<intSum[s-j]; cr++)
 *							if (secu[i+j+1][i+s][cr]!=NONE)
 *								secu[i][i+s][cl+cr+s+1] = max( secu[i][i+s][cl+cr+s+1] , 0.5*(secu[i][i+j][cl] + secu[i+j+1][i+s][cr]) );
 */

#include"stdio.h"
#include <cmath>
#include <algorithm>
using namespace std;

#define MAXN 50 					// maximum number of sites
#define MAXC MAXN*(MAXN+1)/2		// maximum development cost
#define NONE -1						// a finite value for infinity

int N, C;							// number of sites, number of possible connections
double secu[MAXN][MAXN][MAXC];		// secu[i][j][k] is the highest security coefficient that can be reached when 
									// connecting networks 'i' to 'j' at an expense of 'k'
int N_log2_N[MAXC];					// a look-up table for the minimum cost
int intSum[MAXC];					// a look-up table for the maximum cost

bool read_case()
{
	scanf("%d",&N);
	if (N==0) return false;
	
	// reset variables
	C = N*(N+1)/2;
	for (int i=0; i<N; i++)
		for (int j=0; j<N; j++)
			for (int k=0;  k<C; k++)
				secu[i][j][k] = NONE;
	
	// read input
	double iniSecu[N];
	for (int i=0; i<N; i++)
		scanf(" %lf",&iniSecu[i]);
	sort(iniSecu,iniSecu+N);
	for (int i=0; i<N; i++)
		secu[i][i][0] = iniSecu[i];
	return true;
}

void precompute()
{
	for (int i=0; i<MAXC; i++)
	{
		N_log2_N[i] = (int)(floor(log(i*1.0)/log(2.0)))*i;
		intSum[i] = i*(i+1)/2;
	}
}

void max_secu()
{
	for (int s=1; s<N; s++)
		for (int i=0; i<N-s; i++)
			for (int j=s/2; j<s; j++)
				for (int cl=N_log2_N[j+1]; cl<intSum[j+1]; cl++)
					if (secu[i][i+j][cl]!=NONE)
						for (int cr=N_log2_N[s-j]; cr<intSum[s-j]; cr++)
							if (secu[i+j+1][i+s][cr]!=NONE)
								secu[i][i+s][cl+cr+s+1] = max( secu[i][i+s][cl+cr+s+1] , 0.5*(secu[i][i+j][cl] + secu[i+j+1][i+s][cr]) );
}

void output()
{
	double efficiency(NONE);
	int minCost;
	
	for (int i=C-1; i>0; i--)
	{
		//printf("%d : %lf -> %lf\n",i,secu[0][N-1][i],secu[0][N-1][i]/i);
		if (secu[0][N-1][i]!=NONE)
		{
			minCost = i;
			efficiency = max( efficiency, secu[0][N-1][i]/i );
		}
	}
	printf("%.6lf\n",efficiency/secu[0][N-1][C-1]*minCost);
}

int main()
{
	precompute();
	while(read_case())
	{
		max_secu();
		output();
	}
	return 0;
}